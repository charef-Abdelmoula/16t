# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from . import res_company
from . import calendar_event
from . import hr_appraisal
from . import hr_appraisal_goal
from . import hr_appraisal_note
from . import hr_employee
from . import hr_employee_base
from . import hr_employee_public
from . import hr_department
from . import res_config_settings
from . import res_users
